package com.cg.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SuccessView")
public class SuccessView extends HttpServlet {
	
    public SuccessView() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		String purchaseId = (String) request.getAttribute("purchaseId");
		int quantity = (int) request.getAttribute("quantity");
		
		
		out.println("<p>Purchase details added successfully.\n Purchase Id is "+purchaseId);
		out.println("<p>Quantity Remaining: "+ quantity);
		out.print("<p><a href='addPurchasedetails.html'>Go Back</a></p>");
		out.print("<p><a href='menuMPS.html' align='center'>Main Menu</a></p>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
