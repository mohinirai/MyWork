package com.cg.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.MPSMobileBean;


@WebServlet("/GetMobileDetailView")
public class GetMobileDetailView extends HttpServlet {
	
    public GetMobileDetailView() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = response.getWriter();
		
		MPSMobileBean mobBean = (MPSMobileBean) request.getAttribute("mobBean");
		
		out.print("<table>");
		out.print("<tr><th>Mobile Details</th></tr>");
		out.print("<tr><td>Mobile Id</td>"
				+ "<td>"+mobBean.getMobileId()+"</td>");
		
		out.print("<tr><td>Mobile Name</td>"
				+ "<td>"+mobBean.getMobileName()+"</td>");
		
		out.print("<tr><td>Mobile Price</td>"
				+ "<td>"+mobBean.getMobilePrice()+"</td>");
		
		out.print("<tr><td>Quantity Left</td>"
				+ "<td>"+mobBean.getQuantity()+"</td>");
		
		out.print("</table><br/>");
		
		out.print("<p><a href='ViewMobileDetail.html'>Go Back</a></p>");
		out.print("<p><a href='menuMPS.html' align='center'>Main Menu</a></p>");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
