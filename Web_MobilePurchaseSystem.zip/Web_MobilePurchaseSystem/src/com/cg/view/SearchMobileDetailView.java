package com.cg.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.MPSMobileBean;


@WebServlet("/SearchMobileDetailView")
public class SearchMobileDetailView extends HttpServlet {
	
    public SearchMobileDetailView() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
PrintWriter out = response.getWriter();
		
		List<MPSMobileBean> searchMobiles = (List<MPSMobileBean>) request.getAttribute("searchMobiles"); 
		out.print("serach: "+searchMobiles);
		out.print("<table align ='center' width=400px>");
		out.print("<tr><th colspan=4><h3>List Of All Mobiles</h3></th></tr>");
		out.print("<tr><th>Mobile Id</th>"
					+"<th>Mobile Name</th>"
					+ "<th>Price</th>"
					+ "<th>Quantity</th></tr>");
		for (MPSMobileBean mBean : searchMobiles) {
			
			out.print("<tr><td>"+mBean.getMobileId()+"</td>"
					+ "<td>"+mBean.getMobileName()+"</td>"
					+ "<td>"+mBean.getMobilePrice()+"</td>"
					+ "<td>"+mBean.getQuantity()+"</td></tr>");
		}
		out.print("</table><br/>");
		out.print("<p><a href='search.html'>Go Back</a></p>");
		out.print("<p><a href='menuMPS.html' align='center'>Main Menu</a></p>");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
