package com.cg.dao;

public interface MPSQueryMapper {
	
	public static final String INSERT_PURCHASE_DETAIL = "INSERT INTO purchaseDetails VALUES(pIdSequence.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String QUANTITY = "SELECT quantity FROM mobiles WHERE mobileid = ?";
	public static final String GET_PURCHASE_ID="SELECT PIDSEQUENCE.CURRVAL FROM DUAL";
	public static final String GET_ALL_MOBILES_DETAILS = "SELECT mobileid, name, price, quantity FROM mobiles";
	public static final String SEARCH_MOBILES_DETAILS = "SELECT mobileid, name, price, quantity FROM mobiles WHERE price BETWEEN ? AND ?";
	public static final String UPDATE_MOBILE_QUANTITY = "UPDATE mobiles SET quantity = (quantity - 1) WHERE mobileid = ?";
	public static final String REMOVE_MOBILE = "DELETE FROM mobiles WHERE mobileid = ?";
	public static final String GET_MOBILE_DETAIL = "SELECT mobileid, name, price, quantity FROM mobiles WHERE mobileid = ?";
	//public static final String FIND_MOBILE_ID = "SELECT mobileid FROM mobiles WHERE mobileid = ?";
}
