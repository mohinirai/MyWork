package com.cg.dao;

import java.util.List;

import com.cg.beans.MPSMobileBean;
import com.cg.beans.MPSPurchaseBean;
import com.cg.exception.MPSMobileException;

public interface IMPSMobileDao {

	public String addPurchaseDetails(MPSPurchaseBean pb) throws MPSMobileException;

	public List<MPSMobileBean> showAllMobiles() throws MPSMobileException;

	public int updateMobileQuantity(String mobileId) throws MPSMobileException;

	public boolean removeMobile(String mobileId) throws MPSMobileException;
	
	public List<MPSMobileBean> searchMobiles(String minPrice,String maxPrice) throws MPSMobileException;

	public MPSMobileBean viewMobileDetail(String mobileId) throws MPSMobileException;

}
