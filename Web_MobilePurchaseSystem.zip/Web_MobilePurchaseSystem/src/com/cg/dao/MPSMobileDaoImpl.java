package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jdk.internal.org.objectweb.asm.tree.IntInsnNode;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.beans.*;
import com.cg.exception.MPSMobileException;
import com.cg.util.DBConnection;

public class MPSMobileDaoImpl implements IMPSMobileDao {

	Logger logger=Logger.getRootLogger();

	public MPSMobileDaoImpl() {
		 PropertyConfigurator.configure("src//log4j.properties");
	}

	/*******************************************************************************************************
	 - Function Name	:	addPurchaseDetails(MPSPurchaseBean pb)
	 - Input Parameters	:	MPSPurchaseBean
	 - Return Type		:	String
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Insert new purchase details.
	 ********************************************************************************************************/
	
	@Override
	public String addPurchaseDetails(MPSPurchaseBean pb)
			throws MPSMobileException {
		
		Connection conn = null;
		PreparedStatement ps = null;
		String purchaseId = null;
		int queryResult = 0;
		ResultSet rs = null;
		MPSMobileDaoImpl mdi = new MPSMobileDaoImpl();
		
	 
		try {
			
			conn = DBConnection.getInstance().getConnection();
		
			if (conn == null) {
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				if(mdi.checkMobileId(pb.getMobileId())){
					ps = conn.prepareStatement(MPSQueryMapper.QUANTITY);
	
					ps.setString(1, pb.getMobileId());
	
					rs = ps.executeQuery();
					rs.next();
	
					int quant = rs.getInt("quantity");
					ps.close();
					rs.close();
					
					//Check if quantity greater than zero.
					if (quant > 0) {
						
						ps = conn.prepareStatement(MPSQueryMapper.INSERT_PURCHASE_DETAIL);
	
						ps.setString(1, pb.getCustomerName());
						ps.setString(2, pb.getCustomerMailId());
						ps.setString(3, pb.getCustomerPhoneNo());
						ps.setString(4, pb.getMobileId());
	
						queryResult = ps.executeUpdate();
						
						ps = conn.prepareStatement(MPSQueryMapper.GET_PURCHASE_ID);
						rs = ps.executeQuery();
	
						if (rs.next()) {
							purchaseId = rs.getString(1);
							quant = updateMobileQuantity(pb.getMobileId());
						}
						if (queryResult == 0) {
							logger.error("Insertion failed ");
							throw new MPSMobileException("Insertion Failed ");
	
						} else {
							 logger.info("Purchase details added successfully:");
							return purchaseId;
						}
					}
				}
				else
				{
					throw new MPSMobileException("Mobile Id Not Found");
				}
			}
		}
		catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MPSMobileException(e.toString());
		} 
		

		finally {
			try {
				if(rs != null){
					rs.close();
				}
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			}
			catch (SQLException e) {
				
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return purchaseId;

	}

	/*******************************************************************************************************
	 - Function Name	:	showAllMobiles() 
	 - Input Parameters	:	
	 - Return Type		:	List<MPSMobileBean>
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Show all mobiles Details.
	 ********************************************************************************************************/
	
	@Override
	public List<MPSMobileBean> showAllMobiles() throws MPSMobileException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;

		ResultSet resultSet = null;
		
		MPSMobileBean mbean = null;
		List<MPSMobileBean> allMobiles = new ArrayList<MPSMobileBean>();

		try {
			if (conn == null) {
				
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				ps = conn.prepareStatement(MPSQueryMapper.GET_ALL_MOBILES_DETAILS);
				 resultSet = ps.executeQuery();
				 
					while (resultSet.next()) {
						mbean = new MPSMobileBean();
						mbean.setMobileId(resultSet.getString("mobileid"));
						mbean.setMobileName(resultSet.getString("name"));
						mbean.setMobilePrice(resultSet.getString("price"));
						mbean.setQuantity(resultSet.getString("quantity"));
						allMobiles.add(mbean);
					}
			}
		}

		catch (SQLException e) {
			 logger.error(e.getMessage());
			throw new MPSMobileException("Technical Error");
		}

		finally {
			try {
				if(resultSet != null){
					resultSet.close();
				}
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			} catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return allMobiles;
	}

	/*******************************************************************************************************
	 - Function Name	:	updateMobileQuantity(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	int
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Update mobile quantity. 
	 ********************************************************************************************************/
	
	@Override
	public int updateMobileQuantity(String mobileId) throws MPSMobileException {
		Connection conn = DBConnection.getInstance().getConnection();

		PreparedStatement ps = null;

		String purchaseId = null;
		int queryResult = 0;
		ResultSet rs = null;
		int quantity = 0;
		MPSMobileDaoImpl mdi = new MPSMobileDaoImpl();

		try {
			if (conn == null) {
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				if(mdi.checkMobileId(mobileId)){
					ps = conn.prepareStatement(MPSQueryMapper.UPDATE_MOBILE_QUANTITY);
					ps.setString(1, mobileId);
					queryResult = ps.executeUpdate();
					
					if (queryResult == 0) {
						logger.error("Updation Failed ");
						throw new MPSMobileException("Updation Failed ");
					}
					else{
						ps.close();
						
						ps = conn.prepareStatement(MPSQueryMapper.QUANTITY);
	
						ps.setString(1, mobileId);
	
						rs = ps.executeQuery();
						if(rs.next()){
							quantity = rs.getInt("quantity");
							logger.info("Record Updated Successfully");
						}					
					}
				}
				else{
					throw new MPSMobileException("Mobile Id Not Found");
				}
			}
		}
		
		catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MPSMobileException(e.toString());
		}
		finally {
			try {
				if(rs != null){
					rs.close();
				}
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			}
			catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return quantity;
}

	/*******************************************************************************************************
	 - Function Name	:	removeMobile(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	boolean
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	remove mobile detail
	 ********************************************************************************************************/
	
	@Override
	public boolean removeMobile(String mobileId) throws MPSMobileException {
		
		Connection conn = DBConnection.getInstance().getConnection();

		PreparedStatement ps = null;

		String purchaseId = null;
		int queryResult = 0;
		boolean removed = false;
		MPSMobileDaoImpl mdi = new MPSMobileDaoImpl();
		
		try {
			if (conn == null) {
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				if(mdi.checkMobileId(mobileId)){
					ps = conn.prepareStatement(MPSQueryMapper.REMOVE_MOBILE);
					ps.setString(1, mobileId);
					queryResult = ps.executeUpdate();
					
					if (queryResult == 0) {
						logger.error("Deletion Failed ");
						throw new MPSMobileException("Mobile Details Are Not deleted ");
					}
					else {
						 logger.info("Mobile Detail Deleted Successfully");
						removed = true;
						
					}					
				}
				else{
					throw new MPSMobileException("Mobile Id not Found"); 
				}
			}
		}
		
		catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MPSMobileException(e.toString());
		}
		finally {
			try {
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			}
			catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return removed;
	}

	/*******************************************************************************************************
	 - Function Name	:	searchMobiles(String minPrice, String maxPrice)
	 - Input Parameters	:	minPrice, maxPrice
	 - Return Type		:	List<MPSMobileBean>
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Search mobile details based on price range
	 ********************************************************************************************************/
	
	@Override
	public List<MPSMobileBean> searchMobiles(String minPrice, String maxPrice)
			throws MPSMobileException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;

		ResultSet resultSet = null;
		
		MPSMobileBean mbean = null;
		List<MPSMobileBean> mobiles = new ArrayList<MPSMobileBean>();
		
		try {
			if (conn == null) {
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				ps = conn.prepareStatement(MPSQueryMapper.SEARCH_MOBILES_DETAILS);
				ps.setString(1, minPrice);
				ps.setString(2, maxPrice);

				 resultSet = ps.executeQuery();
				
					while (resultSet.next()) {
						mbean = new MPSMobileBean();
						mbean.setMobileId(resultSet.getString("mobileid"));
						mbean.setMobileName(resultSet.getString("name"));
						mbean.setMobilePrice(resultSet.getString("price"));
						mbean.setQuantity(resultSet.getString("quantity"));
						mobiles.add(mbean);
					}
			}
		}

		catch (SQLException e) {
			 logger.error(e.getMessage());
			throw new MPSMobileException(e.toString());
		}

		finally {
			try {
				if(resultSet != null){
					resultSet.close();
				}
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			} catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return mobiles;

	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewMobileDetail(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	MPSMobileBean
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	View specific mobile detail
	 ********************************************************************************************************/

	
	@Override	
	public MPSMobileBean viewMobileDetail(String mobileId) throws MPSMobileException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;

		ResultSet resultSet = null;
		
		MPSMobileBean mobileDetail =null;
		MPSMobileDaoImpl mdi = new MPSMobileDaoImpl();
		
		try {
			if (conn == null) {
				
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				if(mdi.checkMobileId(mobileId)){
					ps = conn.prepareStatement(MPSQueryMapper.GET_MOBILE_DETAIL);
					ps.setString(1, mobileId);
					 resultSet = ps.executeQuery();
					 
						while (resultSet.next()) {
							mobileDetail = new MPSMobileBean();
							mobileDetail.setMobileId(resultSet.getString("mobileid"));
							mobileDetail.setMobileName(resultSet.getString("name"));
							mobileDetail.setMobilePrice(resultSet.getString("price"));
							mobileDetail.setQuantity(resultSet.getString("quantity"));
						}
				}
				else{
					throw new MPSMobileException("Mobile Id not found");
				}
			}
		}

		catch (SQLException e) {
			 logger.error(e.getMessage());
			throw new MPSMobileException("Technical Error");
		}

		finally {
			try {
				if(resultSet != null){
					resultSet.close();
				}
				if(ps != null){
					ps.close();
				}
				if(conn != null){
					conn.close();
				}
			} catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Error in closing database connection");

			}
		}
		return mobileDetail;
	}
	
	public boolean checkMobileId(String mobileId) throws MPSMobileException{
		
		Connection conn = DBConnection.getInstance().getConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		
		try{
			if (conn == null) {
				
				logger.error("Connection Not Established");
				throw new MPSMobileException("Connection Not Established");
			} 
			else {
				ps = conn.prepareStatement(MPSQueryMapper.GET_MOBILE_DETAIL);
				ps.setString(1, mobileId);
				
				rs = ps.executeQuery();
				
				if(rs.next())
						flag = true;
			
			}
		}
			catch (SQLException e) {
				 logger.error(e.getMessage());
				throw new MPSMobileException("Technical Error");
			}

			finally {
				try {
					if(rs != null){
						rs.close();
					}
					if(ps != null){
						ps.close();
					}
					if(conn != null){
						conn.close();
					}
				} catch (SQLException e) {
					 logger.error(e.getMessage());
					throw new MPSMobileException("Error in closing database connection");

				}
			}
		
		return flag;
	}
}
