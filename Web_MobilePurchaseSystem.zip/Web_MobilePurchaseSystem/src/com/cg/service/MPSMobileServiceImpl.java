package com.cg.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.beans.MPSMobileBean;
import com.cg.beans.MPSPurchaseBean;
import com.cg.dao.IMPSMobileDao;
import com.cg.dao.MPSMobileDaoImpl;
import com.cg.exception.MPSMobileException;

public class MPSMobileServiceImpl implements IMPSMobileService{

	/*******************************************************************************************************
	 - Function Name	:	addPurchaseDetails(MPSPurchaseBean pb)
	 - Input Parameters	:	MPSPurchaseBean
	 - Return Type		:	String
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Insert new purchase details.
	 ********************************************************************************************************/
	
	@Override
	public String addPurchaseDetails( MPSPurchaseBean pb) throws MPSMobileException {

		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		String purchaseId = mpsDao.addPurchaseDetails(pb);
		
		
		return purchaseId;
	}

	/*******************************************************************************************************
	 - Function Name	:	showAllMobiles() 
	 - Input Parameters	:	null
	 - Return Type		:	List<MPSMobileBean>
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Show all mobiles Details.
	 ********************************************************************************************************/
	
	@Override
	public List<MPSMobileBean> showAllMobiles() throws MPSMobileException{

		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		List<MPSMobileBean> allMobiles = null;
		allMobiles = mpsDao.showAllMobiles();
		
		return allMobiles;
	}

	/*******************************************************************************************************
	 - Function Name	:	removeMobile(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	boolean
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	remove mobile detail
	 ********************************************************************************************************/
	
	@Override
	public boolean removeMobile(String mobileId) throws MPSMobileException{
		
		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		
		if(mpsDao.removeMobile(mobileId))
			return true;
		else
			return false;
	}

	/*******************************************************************************************************
	 - Function Name	:	updateMobileQuantity(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	int
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Update mobile quantity. 
	 ********************************************************************************************************/
	
	@Override
	public int updateMobileQuantity(String mobileId) throws MPSMobileException{
		
		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		int quantity;
		quantity = mpsDao.updateMobileQuantity(mobileId);
		
		return quantity;
	}

	/*******************************************************************************************************
	 - Function Name	:	searchMobiles(String minPrice, String maxPrice)
	 - Input Parameters	:	minPrice, maxPrice
	 - Return Type		:	List<MPSMobileBean>
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	Search mobile details based on price range
	 ********************************************************************************************************/
	
	@Override
	public List<MPSMobileBean> searchMobiles(String minPrice,String maxPrice) throws MPSMobileException{
		
		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		List<MPSMobileBean> mobiles = null;
		mobiles = mpsDao.searchMobiles(minPrice, maxPrice);
		
		return mobiles;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewMobileDetail(String mobileId)
	 - Input Parameters	:	mobileId
	 - Return Type		:	MPSMobileBean
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	View specific mobile detail
	 ********************************************************************************************************/
	@Override
	public MPSMobileBean viewMobileDetail(String mobileId) throws MPSMobileException {
		IMPSMobileDao mpsDao = new MPSMobileDaoImpl();
		MPSMobileBean mobileDetail = mpsDao.viewMobileDetail(mobileId);
		
		return mobileDetail;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	isValid(MPSPurchaseBean pb)
	 - Input Parameters	:	mobileId
	 - Return Type		:	boolean
	 - Throws			:  	MPSMobileException
	 - Author			:	Mohini
	 - Creation Date	:	27/01/2017
	 - Description		:	View specific mobile detail
	 ********************************************************************************************************/
	
	@Override
  public boolean isValid(MPSPurchaseBean pb) throws MPSMobileException{
		
		boolean valid = false;
		
		if(isValidCustname(pb.getCustomerName())){
			if(isValidMailId(pb.getCustomerMailId())){
				if(isValidPhoneNo(pb.getCustomerPhoneNo())){
					if(isValidMobileId(pb.getMobileId()))
						valid = true;
				}
			}
		}
		
		return valid;
		
	}
	
  	public boolean isValidCustname(String custName) throws MPSMobileException{
  		
  		boolean valid = false;
		Pattern p= Pattern.compile("^[A-Z][a-z]{4,20}$");
		 if (p.matches(p.toString(), custName)){
		 		valid = true;		 		
		 	}
		 	else
		 		throw new MPSMobileException("Invalid Customer Name");
		
		 return valid;	
	}	
  	
  	public boolean isValidPhoneNo(String phoneNo) throws MPSMobileException{
  		
  		boolean valid = false;
  		Pattern p= Pattern.compile("^[7-9][0-9]{9}$");
		 if (p.matches(p.toString(), phoneNo) ){
	 			valid = true; 		
	 		}
	 		else
	 			throw new MPSMobileException("Incorrect Contact Number");
		 return valid;	
	}	
  	

  	public boolean isValidMailId(String mailId) throws MPSMobileException{
  		
  		boolean valid = false;
  		Pattern p= Pattern.compile("^[a-zA-Z0-9#.$]{5,20}@[a-zA-Z]{5,15}.[a-z]{2,4}$");
		 if (p.matches(p.toString(), mailId) ){
	 			valid = true; 		
	 		}
	 		else
	 			throw new MPSMobileException("Incorrect MailId");
		 return valid;	
	}	
	
  	public boolean isValidMobileId(String mobileId) throws MPSMobileException{
  		
  		boolean valid = false;
  		Pattern p= Pattern.compile("^[0-9]{4}$");
		 if (p.matches(p.toString(), mobileId) ){
	 			valid = true; 		
	 		}
	 		else
	 			throw new MPSMobileException("Incorrect MailId");
		 return valid;	
	}	
	

}
