package com.cg.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.MPSMobileException;


public class DBConnection {
	
	private static DBConnection instance = null;
	private  Connection conn = null;
	
	/*****************************************************************
	 - Method Name		:getInstance()
	 - Input Parameters	:	
	 - Return Type		:DBConnection instance
	 - Throws			:MPSMobileException
	 - Author			:Mohini
	 - Creation Date	:26/01/2017
	 - Description		:Singleton and Thread safe class
	*******************************************************************/
	
	public static DBConnection getInstance() throws MPSMobileException {
		if(instance == null){
			instance = new DBConnection();
		}
		return instance;
	}

	public Connection getConnection() throws MPSMobileException {
		
	Properties dbProp = new Properties();
		
		try{
			/*dbProp.load(new FileInputStream("/jdbc.properties"));
			
			String dbUrl = dbProp.getProperty("orclUrl");
			
			String dbUsername = dbProp.getProperty("orclUsername");
			String dbPassword = dbProp.getProperty("orclPassword");*/
			
			//Class.forName(dbDriver);
			//conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
			//System.out.println("Connection Established");
			InitialContext context = new InitialContext();
			DataSource datasource = (DataSource) context.lookup("java:/OracleDS");
			conn = datasource.getConnection();
			
		}
		/*catch(FileNotFoundException fnfe){
			throw new MPSMobileException(fnfe.toString());
		}
		catch(IOException ioe){
			throw new MPSMobileException("Can not read database details.");
		}*/
		catch(SQLException sqle){
			throw new MPSMobileException("Unable to connect with Database");
		}
		/*catch (ClassNotFoundException cnfe) {
			throw new MPSMobileException("JDBC Driver could not be loaded.");
		}*/ 
		
		catch (NamingException e) {
			// TODO Auto-generated catch block
			throw new MPSMobileException("Unable to connect with Database");
		}
		
		
		
		return conn;
	}
	
}
