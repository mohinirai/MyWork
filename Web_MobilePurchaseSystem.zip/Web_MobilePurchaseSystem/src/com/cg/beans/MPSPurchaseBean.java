package com.cg.beans;

import java.time.LocalDate;

public class MPSPurchaseBean {
		
	private String purchaseId;
	private String customerName;
	private String customerMailId;
	private String customerPhoneNo;
	private LocalDate purchaseDate;
	private String mobileId;
	
	
	public String getPurchaseId() {
		return purchaseId;
	}
	
	public void setPurchaseId(String purchaseId) {
		this.purchaseId = purchaseId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getCustomerMailId() {
		return customerMailId;
	}
	
	public void setCustomerMailId(String customerMailId) {
		this.customerMailId = customerMailId;
	}

	public String getCustomerPhoneNo() {
		return customerPhoneNo;
	}
	
	public void setCustomerPhoneNo(String customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}
	
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	
	public String getMobileId() {
		return mobileId;
	}
	
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	
	

}
