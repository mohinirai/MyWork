package com.cg.exception;

public class MPSMobileException extends Exception {
	
	 public MPSMobileException(String errmsg){
		 super(errmsg);
	 }
}
