package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.MPSPurchaseBean;
import com.cg.exception.MPSMobileException;
import com.cg.beans.MPSMobileBean;
import com.cg.service.IMPSMobileService;
import com.cg.service.MPSMobileServiceImpl;

@WebServlet(urlPatterns="*.mvc")
public class MobileController extends HttpServlet {

	public MobileController() {
		
	}

	private void addPurchaseDetailAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String customerName = request.getParameter("cname");
		String customerEmail = request.getParameter("cmail");
		String phoneNo = request.getParameter("cmob");
		String mobileId = request.getParameter("mobId");

		PrintWriter out = response.getWriter();		

		try {
			
			MPSPurchaseBean pbean = new MPSPurchaseBean();
			pbean.setCustomerName(customerName);
			pbean.setCustomerMailId(customerEmail);
			pbean.setCustomerPhoneNo(phoneNo);
			pbean.setMobileId(mobileId);

			IMPSMobileService mService = new MPSMobileServiceImpl();
			String purchaseId = mService.addPurchaseDetails( pbean);
			int quantity = mService.updateMobileQuantity(pbean.getMobileId());
			
			/*out.println("<p>Purchase details added successfully.\n Purchase Id is "+ purchaseId);
			out.println("<p>Quantity Remaining: "+ quantity);*/
			request.setAttribute("purchaseId", purchaseId);
			request.setAttribute("quantity", quantity);
			RequestDispatcher dispatcher = request.getRequestDispatcher("SuccessView");
			dispatcher.forward(request, response);
			
			
			
		} catch (MPSMobileException e) {
			out.print(e.toString());
		}
	}
	private void viewAllAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		IMPSMobileService mService = new MPSMobileServiceImpl();
		
		
		try {
			List<MPSMobileBean> allMobiles = new ArrayList<MPSMobileBean>();
			allMobiles = mService.showAllMobiles();
			//out.print(allMobiles);
			request.setAttribute("allMobiles", allMobiles);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("AllMobilesDetailView");
			dispatcher.forward(request, response);
		} 
		catch (MPSMobileException e) {
			
			out.print(e.toString());
		}
	}
	
	private void getMobileDetailAction(HttpServletRequest request,	HttpServletResponse response) throws ServletException, IOException {
		String mobId = request.getParameter("txtMobId");
		PrintWriter out = response.getWriter();
		
		 try {
			 
			 IMPSMobileService mService = new MPSMobileServiceImpl();
			MPSMobileBean mobileDetail = mService.viewMobileDetail(mobId);
			
			request.setAttribute("mobBean", mobileDetail);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("GetMobileDetailView");
			dispatcher.forward(request, response);
		}
		 catch (MPSMobileException e) {
			 out.print(e.toString());
		}
	}

	
	private void searchMobileDetailAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		
		String minPrice = request.getParameter("txtMinPrice");
		String maxPrice = request.getParameter("txtMaxPrice");
		
		PrintWriter out = response.getWriter();
		
		try {
			 IMPSMobileService mService = new MPSMobileServiceImpl();
			 List<MPSMobileBean> searchMobiles = new ArrayList<MPSMobileBean>();
			 
			 searchMobiles = mService.searchMobiles(minPrice, maxPrice);
			 System.out.println("search: "+searchMobiles);
			 request.setAttribute("searchMobiles",searchMobiles);
			 RequestDispatcher dispatcher = request.getRequestDispatcher("SearchMobileDetailView");
				dispatcher.forward(request, response);
			
		} catch (MPSMobileException e) {
			out.print(e.toString());
		}
	}
	
	private void removeMobileDetailAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String mobId = request.getParameter("txtMobId");
		
		PrintWriter out = response.getWriter();
		 IMPSMobileService mService = new MPSMobileServiceImpl();
		 
		 try {
			if(mService.removeMobile(mobId)){
				
				 /*RequestDispatcher dispatcher = request.getRequestDispatcher("DeleteDetailView");
					dispatcher.forward(request, response); */
				out.print("Mobile Id "+mobId+" deleted successfully.");
				out.print("<p><a href='remove.html'>Go Back</a></p>");
				out.print("<p><a href='menuMPS.html' align='center'>Main Menu</a></p>");
			 }
			else
				out.print("Deletion Failed");
		}
		 catch (MPSMobileException e) {
			out.print(e.toString());
		}
	}

	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getServletPath();
	
		switch(action){		
		
			case "/addPurchasedetailsForm.mvc":
				    	response.sendRedirect("addPurchasedetails.html");
				break;
			case "/addPurchaseDetail.mvc":
						addPurchaseDetailAction(request, response);
				break;
				
			case "/viewAll.mvc":
						viewAllAction(request, response);
				break;

			case "/ViewMobileDetailForm.mvc":
						response.sendRedirect("ViewMobileDetail.html");
				break;
				
			case "/getMobileDetail.mvc":
						getMobileDetailAction(request,response);
				break;
				
			case "/searchForm.mvc":
						response.sendRedirect("search.html");
				break;
			
			case "/searchMobileDetail.mvc":
						searchMobileDetailAction(request,response);
				break;
				
			case "/removeForm.mvc":
						response.sendRedirect("remove.html");
				break;
				
			case "/removeMobileDetail.mvc":
						removeMobileDetailAction(request,response);
				break;
				
			default:					
				break;
		}
	}

	
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);
	}
	

}
