package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public interface PayrollServices
{
	int acceptEmployeeDetails(Employee employee)throws PayrollServicesDownException, SQLException;
	
	Employee getEmployeeDetails(int employeeid)throws EmployeeDetailsNotFoundException,PayrollServicesDownException, SQLException;
	
	List<Employee> getAllEmployeeDetails()throws PayrollServicesDownException , SQLException;
	
	void removeEmployee(int empId) throws SQLException;
	
	public Employee findEmployee(int id);
	
	void updateEmployee(Employee employee)throws SQLException;
	
	public Employee calculateEmployeeNetSalary(Employee employee)throws EmployeeDetailsNotFoundException,PayrollServicesDownException, SQLException;
}