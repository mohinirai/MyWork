package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollDAOServices 
{
	int insertEmployee(Employee employee)throws SQLException;
	
	void updateEmployee(Employee employee)throws SQLException;
	
	void deleteEmployee(int employeeId)throws SQLException;
	
	Employee getEmployee(int employeeId)throws SQLException;

	List<Employee> getAllEmployees()throws SQLException;
	
	public Employee findEmployee(int id);
	public Employee calculateEmployeeNetSalary(Employee employee)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException, SQLException;
}
