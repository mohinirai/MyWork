package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Repository("dao")
public class PayrollDAOServiceImpl implements PayrollDAOServices
{
	Salary sal = new Salary();
	Employee emp = new Employee();
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmpId();
	}

	

	@Override
	public void deleteEmployee(int employeeId) throws SQLException {
		entityManager.remove(entityManager.find(Employee.class, employeeId));
	}


	@Override
	public Employee getEmployee(int employeeId) throws SQLException{
		return entityManager.find(Employee.class,employeeId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		return entityManager.createQuery("From Employee").getResultList();
	}

	@Override
	public Employee findEmployee(int id){
		return entityManager.find(Employee.class, id);
	}
	
	@Override
	public void updateEmployee(Employee employee) throws SQLException{
		
		entityManager.merge(employee);
		
	}	
	@Override
	public Employee calculateEmployeeNetSalary(Employee employee)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException, SQLException {
				Salary sal= employee.getSalary();
				Double hra=sal.getBasicSalary()*0.4,
						ta=sal.getBasicSalary()*0.2,
						da=sal.getBasicSalary()*0.24;
				sal.setHra(hra);
				sal.setTa(ta);
				sal.setDa(da);
				
				Double	grossSal=sal.getBasicSalary()+sal.getHra()+sal.getTa()+sal.getDa()+sal.getCompanyPf()+sal.getEmployeePf();
				
				sal.setGrossSalary(grossSal);
				double annSal=sal.getGrossSalary()*12;
				double annTax=0;
				double invest=employee.getYearlyInvestment();
				if(annSal<=250000)
				{
					annTax=0;
				} 
				else if((annSal>250000)&&(annSal<=500000))
				{

					if(invest<=150000)
					{
						annTax=(annSal-250000-invest)*0.05;
					}
					else
					{
						annTax=(annSal-250000-150000)*0.05;
					}

				}
				else if ((annSal>500000)&&(annSal<=1000000))
				{
					if(invest<=150000)
					{
						annTax=((250000-invest)*0.05)+((annSal-500000)*0.10);
					} 
					else
					{
						annTax=((250000-150000)*0.05)+((annSal-500000)*0.10);
					}
				}
				else if((annSal>1000000)&&(annSal<=10000000))
				{

					if(invest<=150000)
					{
						annTax=((250000-invest)*0.05)+(500000*0.10)+((annSal-1000000)*0.30);
					} 
					else
					{
						annTax=((250000-150000)*0.05)+(500000*0.10)+((annSal-1000000)*0.30);
					}
				}
				else 
				{
					if(invest<=150000)
					{
						annTax=((250000-invest)*0.05)+(500000*0.10)+((annSal-1000000)*0.30)+(annSal*0.02);
					}
					else
					{
						annTax=((250000-150000)*0.05)+(500000*0.10)+((annSal-1000000)*0.30)+(annSal*0.02);
					}
				}
				sal.setMonthlyTax(annTax/12);
				sal.setNetSalary(sal.getGrossSalary()-sal.getMonthlyTax());
				employee.setSalary(sal);
				entityManager.merge(employee);
				return employee;
	}

}
