package com.cg.banking.services;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Service("service")
@Transactional
public class BankingServicesImpl implements BankingServices {

	@Autowired
	BankingDAOServices daoBank;

	@Override
	public int openAccount(int customerId, Account account)
			throws InvalidAmountException, CustomerNotFoundException,
			InvalidAccountTypeException, BankingServicesDownException,
			SQLException, AccountNotFoundException {
		account.setStatus("OPEN");
		account.setPinNumber(generateNewPin());
		return daoBank.insertAccount(customerId, account);
	}

	@Override
	public float depositAmount(int customerId, float amount, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		try {
			Account acct = daoBank.getAccount(customerId, accountNo);
			if (acct != null) {
				System.out.println("Balance "
						+ (acct.getAccountBalance() + amount));
				acct.setAccountBalance(acct.getAccountBalance() + amount);
				Transaction trans = new Transaction();
				trans.setAmount(amount);
				trans.setTransactionType("Deposit");

				return daoBank.insertTransaction(customerId, acct, trans);
			} else
				throw new AccountNotFoundException("Account not found!");
		} catch (SQLException e) {
			throw new BankingServicesDownException();
		}
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		try {
			Account acct = daoBank.getAccount(customerId, accountNo);
			if (acct != null) {
				if (acct.getStatus().equals("OPEN") && acct.getPinCounter() < 3) {
					if (pinNumber == acct.getPinNumber()) {
							acct.setAccountBalance(acct.getAccountBalance() - amount);
							acct.setPinCounter(0);
							Transaction trans = new Transaction();
							trans.setAmount(amount);
							trans.setTransactionType("Debit");
							System.out.println("In Service, account : "+acct);
							System.out.println("In Service, transaction : "+trans);
							return daoBank.insertTransaction(customerId, acct, trans);
						} else{
							  acct.setPinCounter(acct.getPinCounter()+1);
							  throw new InvalidPinNumberException("Incorrect Pin Number. \n You have only "+ (3 - acct.getPinCounter())+ " chances.");
							  }	
				} else{
					acct.setPinCounter(0);
					 acct.setStatus("BLOCKED");
					  daoBank.updateAccount(customerId, acct);
					throw new AccountBlockedException("Access Denied! Your account is blocked. \n Generate new pin and try again..");}
			} else
				throw new AccountNotFoundException("Account not found!");
		} catch (SQLException e) {
			throw new BankingServicesDownException("Server Down!! Try after some time");
		}
	}

	@Override
	public float fundTransfer(int customerIdTo, int accountNoTo,
			int customerIdFrom, int accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		
		if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber) != 0){
			if(depositAmount(customerIdTo, transferAmount, accountNoTo) != 0){
				Account acct = daoBank.getAccount(customerIdFrom, accountNoFrom);
				return acct.getAccountBalance();
			}
			else{
				throw new BankingServicesDownException("Error on reciever's side : ");
			}
		}else{
			throw new BankingServicesDownException("Error on sender side : ");
		}
	}
	@Override
	public Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException, BankingServicesDownException,
			SQLException {
		return daoBank.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException {
		return daoBank.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin() throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException,
			SQLException {
		return daoBank.generatePin();
	}

	@Override
	public boolean changeAccountPin(int customerId, int accountNo,
			int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			SQLException {
		Account acct = daoBank.getAccount(customerId, accountNo);
		if (acct != null) {
			if (oldPinNumber == acct.getPinNumber()) {
				acct.setPinNumber(newPinNumber);
				if (daoBank.updateAccount(customerId, acct))
					return true;
			} else
				throw new InvalidPinNumberException(
						"Old pin is incorrect!! Try Again");
		} else
			throw new AccountNotFoundException("Account not found!!");
		return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException, SQLException {
		return daoBank.getCustomers();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException,
			SQLException {
		return daoBank.getAccounts(customerId);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId,
			int accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException {
		
		try {
			return daoBank.getTransaction(accountNo);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Server Down!!");
		}
	}

	@Override
	public String accountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() throws BankingServicesDownException {
		daoBank.close1();
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BankingServicesDownException, SQLException {
		return daoBank.insertCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId)
			throws BankingServicesDownException, SQLException,
			CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customerId);
		if (cust != null)
			return daoBank.deleteCustomer(customerId);
		else
			throw new CustomerNotFoundException(
					"Customer not found!! Try Again");
	}

	@Override
	public boolean deleteAccount(int customerId, int accountNo)
			throws BankingServicesDownException, SQLException,
			CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customerId);
		if (cust != null){
			System.out.println("In Service  "+ accountNo);
			return daoBank.deleteAccount(customerId, accountNo);}
		else
			throw new CustomerNotFoundException("Customer not found!! Try Again");
	}

	@Override
	public boolean authenticateCustomer(Customer customer)
			throws BankingServicesDownException, SQLException,
			CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customer.getCustomerId());
		if (cust != null) {
			if (customer.getPassword().equals(cust.getPassword()))
				return true;
			else
				return false;
		} else
			throw new CustomerNotFoundException("Customer not found!! Try Again");
	}

	public BankingDAOServices getDaoBank() {
		return daoBank;
	}

	public void setDaoBank(BankingDAOServices daoBank) {
		this.daoBank = daoBank;
	}

	@Override
	public int generateNewPin(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		try { Account acct = daoBank.getAccount(customerId, accountNo);
			if(acct != null){
			 acct.setPinNumber(daoBank.generatePin());
			 acct.setStatus("OPEN");
			 daoBank.updateAccount(customerId, acct);
			 System.out.println("In service, "+acct);
			 System.out.println("pin");
				return acct.getPinNumber();
			 }else
				 throw new AccountNotFoundException("Account not found!!");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Server Down!!");
		}
	}
	
	

}
