package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

@Repository("dao")
public class BankingDAOServicesImpl implements BankingDAOServices {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertCustomer(Customer customer) throws SQLException {
		entityManager.persist(customer);
		entityManager.flush();
		return customer.getCustomerId();
	}

	@Override
	public int insertAccount(int customerId, Account account)	throws SQLException {
		Customer cust = entityManager.find(Customer.class,customerId);
		account.setCustomer(cust);
		entityManager.persist(account);
		cust.setAccount(account);
		entityManager.flush();
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) throws SQLException {
		//Customer cust  = entityManager.find(Customer.class, customerId);
		//account.setCustomer(cust);
		entityManager.merge(account);
		return true;
	}

	@Override
	public int generatePin() throws SQLException {
		double pin = Math.random()*10000;
		return (int)pin;
	}

	@Override
	public float insertTransaction(int customerId, Account acct, Transaction transaction) throws SQLException {
		transaction.setAccount(acct);
		entityManager.persist(transaction);
		acct.setTransactions(transaction);
		entityManager.merge(acct);
		return acct.getAccountBalance();
	}

	@Override
	public boolean deleteCustomer(int customerId) throws SQLException {
		Customer cust = entityManager.find(Customer.class, customerId);
		entityManager.remove(cust);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, int accountNo)	throws SQLException {
		//Account acct = entityManager.find(Account.class, accountNo);
		entityManager.remove(getAccount(customerId, accountNo));
			return true;
	}

	@Override
	public Customer getCustomer(int customerId) throws SQLException {
		Customer cust = entityManager.find(Customer.class, customerId);
		return cust;
	}

	@Override
	public Account getAccount(int customerId, int accountNo) throws SQLException {
		Account acct = entityManager.find(Account.class, accountNo);
		return acct;
	}

	@Override
	public List<Customer> getCustomers() throws SQLException {
		TypedQuery<Customer> query = entityManager.createQuery("FROM Customer c", Customer.class);
		List<Customer> allCustomer = query.getResultList();
		System.out.println(allCustomer);
		return allCustomer;
	}

	@Override
	public List<Account> getAccounts(int customerId) throws SQLException {
		Customer cust = new Customer();
		cust.setCustomerId(customerId);
		TypedQuery<Account> query = entityManager.createQuery("From Account a WHERE a.customer =:cid", Account.class);
		query.setParameter("cid", cust);
		List<Account> allAccounts = query.getResultList();
		return allAccounts;
	}

	@Override
	public List<Transaction> getTransaction(int accountNo) throws SQLException {
		Account account = new Account();
		account.setAccountNo(accountNo);
		TypedQuery<Transaction> query = entityManager.createQuery("FROM Transaction t WHERE t.account =:ano", Transaction.class);
		query.setParameter("ano", account);
		List<Transaction> allTrans = query.getResultList();
		return allTrans;
	}

	@Override
	public void close1() {
		
	}
}