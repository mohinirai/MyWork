package com.cg.banking.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;
import com.itextpdf.text.pdf.PdfWriter;
import com.sun.org.apache.xpath.internal.operations.Mod;

@Controller
public class BankController {

	@Autowired
	BankingServices serviceBank;

	// ShowingLoginPage
	@RequestMapping(value = "showLogin")
	public ModelAndView showLoginPage() {
		return new ModelAndView("login", "customer", new Customer());
	}

	// LoginAttempt
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String loginCustomer(@ModelAttribute("customer") Customer cust,	Model model, HttpServletRequest req) {
		String result = "login";
		String message = null;
		try {
			if((Integer)cust.getCustomerId() != null && cust.getPassword() != null){
				if (serviceBank.authenticateCustomer(cust)) {
				HttpSession session = req.getSession();
				Customer customer = serviceBank.getCustomerDetails(cust.getCustomerId());
				session.setAttribute("customer", customer);
				if (cust.getCustomerId() == 0){
					List<Customer> allCustomers = serviceBank.getAllCustomerDetails();
					session.setAttribute("allCustomers", allCustomers);
					result = "adminHome";
				}
				else{
					getAllAccounts(customer,req);
					result = "home";
				}
			} else {
				message = "Username Or password Incorrect";
				result = "login";}
			} else {
				message = "Fields can not be empty!!";
				result = "login";
			}
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
			result = "login";
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
			message = "Something went wrong!! Please try again."+ e.getMessage();
			result = "login";
		} catch (SQLException e) {
			throw new BankingServicesDownException();
		} catch (Exception e) {
			message = "Something went wrong!! Please try again." + e.toString();
			e.printStackTrace();
			result = "login";
		} finally {
			model.addAttribute("message", message);
			return result;
		}
	}

	// Show SignUp Page
	@RequestMapping(value = "showAddCustomerPage")
	public ModelAndView showAddCustomerPage() {
		return new ModelAndView("addCustomer", "customer", new Customer());
	}

	// Adding Customer in DB
	@RequestMapping(value = "addCustomer")
	public String addCustomer(@ModelAttribute("customer") Customer cust,Model model, HttpServletRequest req) throws BankingServicesDownException {
		String message = null;
		HttpSession session = req.getSession();
		try {
			int custId = serviceBank.acceptCustomerDetails(cust);
			if (custId != 0) {
				message = "New Customer is successfully registered. Customer Id is "+ custId;
				List<Customer> allCustomers = serviceBank.getAllCustomerDetails();
				System.out.println("In Controller--"+allCustomers);
				session.setAttribute("allCustomers", allCustomers);
			}
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
			message = "Server Error. Please try again";
		} catch (SQLException e) {
			throw new BankingServicesDownException();
		}
		model.addAttribute("message", message);
		return "adminHome";
	}

	// show Update Page
	@RequestMapping(value = "showDetailsPage")
	public String showDetailsPage(@ModelAttribute("customer") Customer customer,@RequestParam(value = "id") int id, HttpServletRequest req) throws BankingServicesDownException {
		HttpSession session = req.getSession();
		try {
			Customer cust = serviceBank.getCustomerDetails(id);
			//model.addAttribute("custDetail", cust);
			session.setAttribute("custDetail", cust);
			getAllAccounts(cust, req);			
		} catch (CustomerNotFoundException e) {
			return "adminHome";
		} catch (BankingServicesDownException e) {
			return "adminHome";
		} catch (SQLException e) {
			throw new BankingServicesDownException("Server Down!!");
		}
		return "detail";
	}

	// Show OpenAccount Page
	@RequestMapping(value = "openAccountPage")
	public ModelAndView openAccountPage() {
		return new ModelAndView("openAccountPage", "account", new Account());
	}

	@RequestMapping(value = "openAccount")
	public ModelAndView openAccount(@ModelAttribute("account") Account account, Model model, HttpServletRequest req) {
		try {
			HttpSession session =req.getSession();
			Customer cust = (Customer)session.getAttribute("customer");
			System.out.println("in controller  "+cust);
			int accountNo = serviceBank.openAccount(cust.getCustomerId(), account);
			getAllAccounts(serviceBank.getCustomerDetails(cust.getCustomerId()),req);
			model.addAttribute("message","New account added successfully. Your account number is "+ accountNo+". Your Pin is "+account.getPinNumber());
			} catch (CustomerNotFoundException | BankingServicesDownException| SQLException | InvalidAmountException | InvalidAccountTypeException | AccountNotFoundException e) {
				e.printStackTrace();
				return new ModelAndView("openAccountPage","message",e.toString());
			}			
		return new ModelAndView("home");
	}

	// Show transaction
	@RequestMapping(value = "performTransaction")
	public ModelAndView openTransactionPage() {
		return new ModelAndView("openTransactionPage");
	}
	
	//Deposit
	@RequestMapping(value = "showDepositPage")
	public ModelAndView openDepositPage() {
		return new ModelAndView("deposit", "trans",	new Transaction());
	}
	
	@RequestMapping(value = "deposit")
	public ModelAndView depositAmount(@RequestParam("accountNo")int accountNo,@RequestParam("amount")int amount, Model model, HttpServletRequest req) throws SQLException {
		HttpSession session =req.getSession();
		try {
				Customer cust = (Customer) session.getAttribute("customer");
				if(cust != null){
				float balance = serviceBank.depositAmount(cust.getCustomerId(), amount, accountNo);
				getAllAccounts(cust,req);
				model.addAttribute("message", "Amount deposited from account "+accountNo+". /n  Balance = "+balance);
				}
				else{
					throw new CustomerNotFoundException("Customer not found");
				}
		}  catch (AccountNotFoundException e) {
				return new ModelAndView("deposit","message","Account not found");
		} catch (BankingServicesDownException e){
				e.printStackTrace();
				return new ModelAndView("deposit","message","Server Down!! Try after some time");
		} catch (CustomerNotFoundException e) {
			return new ModelAndView("deposit");
		}
			return new ModelAndView("home");
		}
	
	//withdraw
	@RequestMapping("showWithDrawlPage")
	public String showWithDrawlPage(){		
		return "ShowToWithDrawl";	
	}
	
	@RequestMapping("withDrawl")
	public ModelAndView withDrawlComplete(@RequestParam("accountNo")int accountNo,@RequestParam("amount")float amount,@RequestParam("pinNumber")int pinNumber,Model model,HttpServletRequest req){
		HttpSession session =req.getSession();
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			float balance = serviceBank.withdrawAmount(cust.getCustomerId(), accountNo, amount, pinNumber);
			getAllAccounts(cust,req);
			model.addAttribute("message", "Amount debited from account "+accountNo+". /n  Balance = "+balance);
		} catch (InsufficientAmountException | CustomerNotFoundException
				| AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException
				| SQLException e) {
			return new ModelAndView("ShowToWithDrawl","message",e.toString());
		}		
		return new ModelAndView("home");
	}
	//fund transfer
	@RequestMapping("showFundTransfer")
	public String fundTransfer(){		
		return "ShowFundTransfer";	
	}
	@RequestMapping("transferComplete")
	public ModelAndView transferComplete(@RequestParam("accountNoFrom")int fromAccount,@RequestParam("customerIdTo")int toCust,@RequestParam("accountNoTo")int toAccount,@RequestParam("amountTransfer")float amount,@RequestParam("pinNumber")int pinNumber,Model model,HttpServletRequest req){
		HttpSession session =req.getSession();
		try {
			Customer fromCust = (Customer) session.getAttribute("customer");
			float balance = serviceBank.fundTransfer( toCust, toAccount, fromCust.getCustomerId(), fromAccount,amount, pinNumber);
			if(balance != 0){
			getAllAccounts(fromCust,req);
			model.addAttribute("message","Amount transfered successfully./n Balance = "+balance);
			}
		} catch (InsufficientAmountException | CustomerNotFoundException
				| AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException
				| SQLException e) {
			e.printStackTrace();
			return new ModelAndView("ShowFundTransfer","message",e.toString());
		}
		return new ModelAndView("home");
	}
	// Delete customer
	@RequestMapping(value = "deleteCustomer")
	public ModelAndView deleteCustomer(@RequestParam(value = "id") int id) {
		String message = null;
		try {
			if (serviceBank.deleteCustomer(id))
				message = "Customer removed Successfully.";
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("adminHome", "message", message);
	}
	
	//Delete Account
	@RequestMapping("deleteAccount")
	public ModelAndView deleteAccount(@RequestParam(value="accountNo") int accountNo,HttpServletRequest req) {
		String message = null;
		HttpSession session = req.getSession();
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			if (serviceBank.deleteAccount(cust.getCustomerId(), accountNo)){
				System.out.println("Going to service");
				getAllAccounts(cust,req);
				message = "account removed Successfully.";				
			}
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("home", "message", message);
	}
	
	//Change pin
	@RequestMapping(value = "showChangePin")
	public ModelAndView showChangePin(@RequestParam(value="accountNo") int accountNo,HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.setAttribute("accountNo", accountNo);
		return new ModelAndView("changePin");
	}
	
	@RequestMapping(value = "changePin")
	public ModelAndView changePin(@RequestParam(value="oldPin") int oldPin,@RequestParam(value="newPin")int newpin,HttpServletRequest req) {
		String message = null;
		HttpSession session = req.getSession();
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			if (serviceBank.changeAccountPin(cust.getCustomerId(), (int)session.getAttribute("accountNo"),oldPin, newpin)){
				getAllAccounts(cust,req);
				message = "Pin updated Successfully.";				
			}
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException | AccountNotFoundException | InvalidPinNumberException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("home", "message", message);
	}
	
	@RequestMapping(value="generateNewPin")
	public ModelAndView generateNewPin(@RequestParam(value="accountNo") int accountNo, HttpServletRequest req) {
		String message = null;
		HttpSession session = req.getSession();
		System.out.println("hellooooo");
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			System.out.println("going to find pin");
			int pin = serviceBank.generateNewPin(cust.getCustomerId(), accountNo); 
			System.out.println("pin is ="+pin);
			if (pin != 0){
				getAllAccounts(cust,req);
				message = "Your new pin for account number "+accountNo+" is "+pin;				
			}
		} catch (BankingServicesDownException | CustomerNotFoundException | AccountNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("home", "message", message);
	}
	
	//all accounts
	public void getAllAccounts(Customer customer,HttpServletRequest req){
		List<Account> allAccounts= null;
		HttpSession session = req.getSession();
		try {
			allAccounts = serviceBank.getcustomerAllAccountDetails(customer.getCustomerId());
			session.setAttribute("allAccounts", allAccounts);
		} catch (BankingServicesDownException | CustomerNotFoundException| SQLException e) {
			e.printStackTrace();
		}
	}
	
	//
	@RequestMapping("getAllTransaction")
	public ModelAndView getAllTransactions(@RequestParam(value="accountNo") int accountNo, Model model, HttpServletRequest req){
		List<Transaction> allTransactions= null;
		HttpSession session = req.getSession();
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			allTransactions = serviceBank.getAccountAllTransaction(cust.getCustomerId(), accountNo);
			model.addAttribute("accountNo",accountNo);
		} catch (BankingServicesDownException | CustomerNotFoundException| AccountNotFoundException e) {
			e.printStackTrace();
			return new ModelAndView("home","message",e.getMessage());
		}
		return new ModelAndView("showTransaction","allTransactions",allTransactions);
	}

	@RequestMapping(value ="generatepdf")
	public void generate(@RequestParam("accountNo") int accountNo,Map<String, Object> model,HttpServletRequest req, HttpServletResponse res) throws SQLException, BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		Document document = new Document();
		HttpSession session = req.getSession();
		Customer cust = (Customer) session.getAttribute("customer");
		List<Transaction> transactions= serviceBank.getAccountAllTransaction(cust.getCustomerId(), accountNo);
		String pdfName= accountNo +".pdf";
		System.out.print("Inside  genratePdf " + transactions);
		File pdfFoler =new File("d:\\CGBankPDf");
		if(!pdfFoler.exists())
			pdfFoler.mkdir();
		File pdffFile= new File(pdfFoler.getAbsolutePath()+"\\"+pdfName);
		try
		{
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdffFile));
			document.open();

			PdfPTable table = new PdfPTable(3);
			PdfPCell c1=null;

			c1 = new PdfPCell(new Phrase("Transaction ID"));
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);

			c1 = new PdfPCell(new Phrase("Amount"));
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);

			c1 = new PdfPCell(new Phrase("Transaction Type"));
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);

			table.setHeaderRows(1);
			for (Transaction transaction : transactions) {
				table.addCell(Integer.toString(transaction.getTransactionId()));
				table.addCell(Float.toString(transaction.getAmount()));
				table.addCell(transaction.getTransactionType());
			}

			
			document.add(table);

			document.close();
			writer.close();

			byte []buffer = new byte[(int)pdffFile.length()]; 
			try( FileInputStream reader = new FileInputStream(pdffFile)){
				reader.read(buffer);
				res.setHeader("Content-disposition", "inline;filename="+pdffFile.getName());
				try(ServletOutputStream out = res.getOutputStream()){
					res.setContentType("application/pdf");
					out.write(buffer);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		catch (DocumentException e){
			e.printStackTrace();
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
	}
	
	//Logout
	
	@RequestMapping("logout")
	public ModelAndView logout(HttpServletRequest req){
		HttpSession session = req.getSession();
		session.invalidate();
		return new ModelAndView("login","customer", new Customer());
	}
}
