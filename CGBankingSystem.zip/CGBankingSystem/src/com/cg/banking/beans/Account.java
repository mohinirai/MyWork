package com.cg.banking.beans;

import java.io.Serializable;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@SuppressWarnings("serial")
@Entity
public class Account implements Serializable{

	
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int pinNumber;
	private String status;
	private int pinCounter;
	
	@ManyToOne(targetEntity=Customer.class)
	@JoinColumn(name="customerId")
	private Customer customer;
	
	@ElementCollection
	@OneToMany(mappedBy="account" , cascade= CascadeType.ALL,fetch=FetchType.EAGER)
	private Map<Integer, Transaction> transactions;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPinCounter() {
		return pinCounter;
	}

	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}

	public Map<Integer, Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction transactions) {
		this.transactions.put(this.transactions.size(), transactions);
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", pinNumber=" + pinNumber + ", status=" + status
				+ ", pinCounter=" + pinCounter + "]";
	}

}
