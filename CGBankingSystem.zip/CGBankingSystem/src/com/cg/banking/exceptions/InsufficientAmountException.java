package com.cg.banking.exceptions;

public class InsufficientAmountException extends Exception {
	String message;
	public InsufficientAmountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message) {
		super(message);
		this.message = message;
	}

	public InsufficientAmountException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return message;
	}

}
