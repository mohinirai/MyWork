package com.capgemini.contactbook.service;

import java.util.regex.Pattern;

import oracle.net.aso.f;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.dao.IContactBookDao;
import com.capgemini.contactbook.exception.ContactBookException;


public class ContactBookServiceImpl implements IContactBookService {
	
	IContactBookDao conBookDao = new ContactBookDaoImpl();
	/*******************************************************************************************************
	 - Function Name	:	addEnquiry(EnquiryBean enqry)
	 - Input Parameters	:	EnquiryBean 
	 - Return Type		:	int
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	:30/01/2017
	 - Description		:	Insert new enquiry details.
	 ********************************************************************************************************/
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		int enquiryId = 0;
		enquiryId = conBookDao.addEnquiry(enqry);
		
		return enquiryId;
	}

	/*******************************************************************************************************
	 - Function Name	:	getEnquiryDetails(int enquiryID)
	 - Input Parameters	:	enquiryID 
	 - Return Type		:	EnquiryBean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Get enquiry detail based on Id.
	 ********************************************************************************************************/
	
	@Override
	public EnquiryBean getEnquiryDetails(int enquiryID)
			throws ContactBookException {
		
		EnquiryBean enqry = null;
		enqry = conBookDao.getEnquiryDetails(enquiryID);
		
		return enqry;
	}

	/*******************************************************************************************************
	 - Function Name	:	isValidEnquiry(EnquiryBean enqry)
	 - Input Parameters	:	EnquiryBean
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate inputs.
	 ********************************************************************************************************/
	
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)throws ContactBookException {
		
		ContactBookServiceImpl conBookService = new ContactBookServiceImpl();
		boolean valid = false;
		
		if(conBookService.validateFirstName(enqry.getfName())){
			if(conBookService.validateLastName(enqry.getlName())){
				if(conBookService.validateContactNo(enqry.getContactNo())){
					if(conBookService.validatePDomain(enqry.getpDomain())){
						if(conBookService.validatePLocation(enqry.getpLocation()))
							valid = true;
						else
					 		throw new ContactBookException("Invalid Location Name");
					}
					else
				 		throw new ContactBookException("Invalid Domain Name");
				
				}
				else
			 		throw new ContactBookException("Invalid Contact number");
			
			}
			else
		 		throw new ContactBookException("Invalid Last Name");
		}
		else
	 		throw new ContactBookException("Invalid First Name");	
		
		return valid;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateContactNo(String contactNo)
	 - Input Parameters	:	contactNo
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate contact number .
	 ********************************************************************************************************/
	
	public boolean validateContactNo(String contactNo)throws ContactBookException{
		boolean flag = false;
		Pattern p= Pattern.compile("^[7-9][0-9]{9}$");
		 if (p.matches(p.toString(), contactNo) ){
	 			flag = true; 		
	 		}
	 		
		return flag;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateFirstName(String fName)
	 - Input Parameters	:	fName
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate First Name .
	 ********************************************************************************************************/
	
	public boolean validateFirstName(String fName)throws ContactBookException{
	 boolean flag = false;
		Pattern p= Pattern.compile("^[A-Z][a-z]{2,20}$");
		 if (p.matches(p.toString(), fName)){
		 		flag = true;		 		
		 	}
		 	
		
		 return flag;	
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateLastName(String lName)
	 - Input Parameters	:	lName
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate last Name .
	 ********************************************************************************************************/
	
	public boolean validateLastName(String lName) throws ContactBookException{
		boolean flag = false;
		Pattern p= Pattern.compile("^[A-Z][a-z]{2,20}$");
		 if (p.matches(p.toString(), lName)){
		 		flag = true;		 		
		 	}
		 	
		 return flag;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validatePLocation(String pLocation)
	 - Input Parameters	:	pLocation
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate preferred location .
	 ********************************************************************************************************/
	
	public boolean validatePLocation(String pLocation) throws ContactBookException{
		boolean flag = false;
		Pattern p= Pattern.compile("^[a-zA-Z]{2,20}$");
		 
		 if (p.matches(p.toString(), pLocation)){
		 		flag = true;		 		
		 	}
		 	
		
		 return flag;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validatePDomain(String pDomain)
	 - Input Parameters	:	pDomain
	 - Return Type		:	boolean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Validate preferred domain .
	 ********************************************************************************************************/
	
	public boolean validatePDomain(String pDomain) throws ContactBookException{
		boolean flag = false;
		Pattern p= Pattern.compile("^[a-zA-Z]{2,20}$");
		 if (p.matches(p.toString(), pDomain)){
		 		flag = true;		 		
		 	}
		 	
		 return flag;
	}
}
