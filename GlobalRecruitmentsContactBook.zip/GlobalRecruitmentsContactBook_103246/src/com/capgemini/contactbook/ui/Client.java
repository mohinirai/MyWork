package com.capgemini.contactbook.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.*;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.service.IContactBookService;

public class Client {
	public static void main(String[] args) {
		
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("resources/log4j.properties");

		Scanner scan = new Scanner(System.in);
		String choice = "";
		
		IContactBookService conBookService = new ContactBookServiceImpl();
		
		System.out.println("***************Global Recruitments***************");
		
		do{
			
			System.out.println("\tChoose an operation");
			System.out.println("\t1. Enter Enquiry Details\n\t2. View Enquiry Details on Id\n\t0. Exit");
			System.out.println("*************************************************");
			System.out.print("Please enter a choice: ");
			choice = scan.next();
			System.out.println("*************************************************");
			 
			 switch(choice){
				 case "1":
					 // Insert new enquiry
					 	String firstName = "";
					 	String lastname = "";
					 	String contactNo = "";
					 	String domain = "";
					 	String location = "";
					 	try{
						 	System.out.print("Enter First Name : ");
						 	firstName = scan.next();
						 	
						 	System.out.print("\nEnter Last name : ");
						 	lastname = scan.next();
						 	
						 	System.out.print("\nEnter Contact Number : ");
						 	contactNo = scan.next();
						 	
						 	System.out.print("\nEnter Preferred Domain :");
						 	domain = scan.next();
						 	
						 	System.out.println("\nEnter Preferred Location :");
						 	location = scan.next();
						 	
						 	EnquiryBean enquiry = new EnquiryBean();
						 	
						 	enquiry.setfName(firstName);
						 	enquiry.setlName(lastname);
						 	enquiry.setContactNo(contactNo);
						 	enquiry.setpDomain(domain);
						 	enquiry.setpLocation(location);
						 	
						 	if(conBookService.isValidEnquiry(enquiry)){
						 		
						 		int enquiryId = conBookService.addEnquiry(enquiry);
						 		if(enquiryId != 0){
						 			System.out.println("Thank you "+firstName+" "+lastname+". Your Unique id is "
						 					+enquiryId+". We will contact you shortly.");
						 		}
						 	}
					 	}
					 	catch(ContactBookException conBookException){
					 		logger.error(conBookException.getMessage());
					 		System.err.println("Error: "+conBookException);
					 	}
					 break;
				 
				 case "2":
					 	// get enquiry details based on Id
					 
					 	System.out.println("Enter the Enquiry No: ");
					 	
					 	int enquiryId = scan.nextInt();
					 	
					 	try{
					 		System.out.println(enquiryId);
					 		EnquiryBean enqry = conBookService.getEnquiryDetails(enquiryId);
					 		if(enqry != null){
					 			System.out.println("Id\tFirst Name\tLast Name\tContact No.\t Preferred domain\tPreferred Location");
					 			System.out.println(enqry.getEnqryId()+"\t"+enqry.getfName()+"\t"+enqry.getlName()+"\t"
					 							+enqry.getContactNo()+"\t"+enqry.getpDomain()+"\t"+enqry.getpLocation());
					 		}
					 		else
					 			System.out.println("No Enquiry Found");
					 		
					 	}
					 	catch(ContactBookException conBookException){
					 		logger.error(conBookException.getMessage());
					 		System.err.println("Error: "+conBookException);
					 	}
					 	
					 break;
				 
				 case "0":
					 
					 	System.out.println("Thank you for selecting us!!");
					 	System.exit(1);
					 break;
				 
				 default:
					 System.out.println("Enter valid Choice[0-2]");
					 break;
			 }
			 System.out.println("*************************************************");
			  
		}while(true);
	}
}
