package com.capgemini.contactbook.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.contactbook.exception.ContactBookException;


public class ContactBookDBConnection {
	
	private static ContactBookDBConnection instance = null;
	private  Connection conn = null;
	
	/*****************************************************************
	 - Method Name		:getInstance()
	 - Input Parameters	:	
	 - Return Type		:ContactBookDBConnection instance
	 - Throws			:ContactBookException
	 - Author			:Mohini
	 - Creation Date	:30/01/2017
	 - Description		:Singleton and Thread safe class
	*******************************************************************/
	public static ContactBookDBConnection getInstance() throws ContactBookException {
		if(instance == null){
			instance = new ContactBookDBConnection();
		}
		return instance;
	}

	/**********************************************************************************************
	 - Method Name		:getConnection()
	 - Input Parameters	:	
	 - Return Type		:Connection instance
	 - Throws			:ContactBookException
	 - Author			:Mohini
	 - Creation Date	:30/01/2017
	 - Description		:Loads the  jdbc.properties file  and create the database connection
	*************************************************************************************************/
	
	public Connection getConnection() throws ContactBookException{
		
	Properties dbProp = new Properties();
		
		try{
			dbProp.load(new FileInputStream("resources/jdbc.properties"));
			
			String dbUrl = dbProp.getProperty("orclUrl");
			String dbUsername = dbProp.getProperty("orclUsername");
			String dbPassword = dbProp.getProperty("orclPassword");
			
			conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
			//System.out.println("Connection Established");
		}
		catch(FileNotFoundException fnfe){
			throw new ContactBookException("Unable to find JDBC properties file.");
		}
		catch(IOException ioe){
			throw new ContactBookException("Unable to read database details.");
		}
		catch(SQLException sqle){
			throw new ContactBookException("Unable to connect with Database");
		}
		
		return conn;
	}
}
