package com.capgemini.contactbook.dao;

public interface ContactBookQueryMapper {
	
	public static final String INSERT_ENQUIRY_DETAILS = "INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?,?)";
	public static final String GET_ENQUIRIES = "SELECT enquiries.CURRVAL fROM dual";
	public static final String GET_ENQUIRY_DETAILS = "SELECT enqryId, firstName, lastName , contactNo , domain ,city FROM enquiry WHERE enqryId = ?";
}
