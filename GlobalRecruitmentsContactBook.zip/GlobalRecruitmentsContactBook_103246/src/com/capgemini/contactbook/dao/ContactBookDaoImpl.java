package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.ContactBookDBConnection;




public class ContactBookDaoImpl implements IContactBookDao {

	Logger logger=Logger.getRootLogger();
	Connection conn = null;
	PreparedStatement ps = null;

	public ContactBookDaoImpl(){
		 PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addEnquiry(EnquiryBean enqry)
	 - Input Parameters	:	EnquiryBean 
	 - Return Type		:	int
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	:30/01/2017
	 - Description		:	Insert new enquiry details.
	 ********************************************************************************************************/
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		conn = ContactBookDBConnection.getInstance().getConnection();
		
		int queryResult = 0;
		ResultSet resultSet = null;
		int enquiryID = 0;
		
		try {
			if (conn == null) {
				
				logger.error("Connection Not Established");
				throw new ContactBookException("Connection Not Established");
			} 
			else {
				
					ps = conn.prepareStatement(ContactBookQueryMapper.INSERT_ENQUIRY_DETAILS);
					ps.setString(1, enqry.getfName());
					ps.setString(2, enqry.getlName());
					ps.setString(3, enqry.getContactNo());
					ps.setString(4, enqry.getpDomain());
					ps.setString(5, enqry.getpLocation());
					
					queryResult = ps.executeUpdate();
					
					ps = conn.prepareStatement(ContactBookQueryMapper.GET_ENQUIRIES);
					resultSet = ps.executeQuery();
					
					if(resultSet.next())
						enquiryID = resultSet.getInt(1);
					
					if(queryResult == 0){
						
						logger.error("Insertion failed ");
						throw new ContactBookException("Enquiry Details Are Not Inserted.\n Please Try Again ");
					}
					else{
						logger.info("Enquiry details added successfully. Enquiry ID is "+enquiryID);
						return enquiryID;
					}
				}
			}
		
			catch(SQLException sqle){
			logger.error(sqle.getMessage());
			throw new ContactBookException(sqle.toString());
			}
		
			finally {
				try {
					if(resultSet != null){
						resultSet.close();
					}
					if(ps != null){
						ps.close();
					}
					if(conn != null){
						conn.close();
					}
				}
				catch (SQLException e) {
					 logger.error(e.getMessage());
					throw new ContactBookException("Error in closing database connection");
	
				}
			}
	}

	/*******************************************************************************************************
	 - Function Name	:	getEnquiryDetails(int enquiryID)
	 - Input Parameters	:	enquiryID 
	 - Return Type		:	EnquiryBean
	 - Throws			:  	ContactBookException
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	Get enquiry detail based on Id.
	 ********************************************************************************************************/
	
	@Override
	public EnquiryBean getEnquiryDetails(int enquiryID)throws ContactBookException {
		
		conn = ContactBookDBConnection.getInstance().getConnection();
		ResultSet resultSet = null;
		
		EnquiryBean enqry = null;
		
		try {
			if (conn == null) {
				
				logger.error("Connection Not Established");
				throw new ContactBookException("Connection Not Established");
			} 
			else {
				
					ps = conn.prepareStatement(ContactBookQueryMapper.GET_ENQUIRY_DETAILS);
					ps.setInt(1, enquiryID);
					
					resultSet = ps.executeQuery();					
					
					while (resultSet.next()) {
						enqry = new EnquiryBean();
						enqry.setEnqryId(resultSet.getInt("enqryId"));
						enqry.setfName(resultSet.getString("firstName"));
						enqry.setlName(resultSet.getString("lastName"));
						enqry.setContactNo(resultSet.getString("contactNo"));
						enqry.setpDomain(resultSet.getString("domain"));
						enqry.setpLocation(resultSet.getString("city"));
					}
			}
		}
		catch(SQLException sqle){
			logger.error(sqle.getMessage());
			throw new ContactBookException(sqle.toString());
		}
		
			finally {
				try {
					if(resultSet != null){
						resultSet.close();
					}
					if(ps != null){
						ps.close();
					}
					if(conn != null){
						conn.close();
					}
				}
				catch (SQLException e) {
					 logger.error(e.getMessage());
					throw new ContactBookException("Error in closing database connection");
	
				}
			}
		
		return enqry;
	}
}
