package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception {
	String errmsg;
	public ContactBookException(String errmsg) {
		super(errmsg);		
	}
	
	/*******************************************************************************************************
	 -Override toString()
	 - Return Type		:	String
	 - Author			:	Mohini
	 - Creation Date	:	30/01/2017
	 - Description		:	
	 ********************************************************************************************************/
	
	public String toString(){
		return "["+errmsg+"]";
	}
}
