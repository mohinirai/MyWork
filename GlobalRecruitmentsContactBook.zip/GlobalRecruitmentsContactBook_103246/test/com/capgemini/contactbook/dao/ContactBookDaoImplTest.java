package com.capgemini.contactbook.dao;

import org.junit.After;
import org.junit.Before;

import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookDaoImplTest {
	private ContactBookDaoImpl daoTest = null;
	
	@Before
	public void setUp() throws ContactBookException{
		daoTest = new ContactBookDaoImpl();
	}
	
	@After
	public void tearDown() throws ContactBookException{
		daoTest = null;
	}
	
	
}
